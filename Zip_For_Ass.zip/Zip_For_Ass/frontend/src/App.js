import React, { useEffect, useState } from 'react';
import axios from 'axios'; // Import axios

import './App.css';

function App() {
  const [isStarted, setIsStarted] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [positionsArray, setPositionsArray] = useState([]);

  const handleStartClick = () => {
    setIsStarted(true);
  };

  const handlePanelMouseDown = (e) => {
    if (isStarted && !isDragging) {
      setIsDragging(true);
      handleMouseMove(e);
    }
  };

  const handleMouseMove = (e) => {
    if (isDragging) {
      const rect = e.currentTarget.getBoundingClientRect();
      const offsetX = e.clientX - rect.left;
      const offsetY = e.clientY - rect.top;
      setPosition({
        x: Math.min(Math.max(0, offsetX), rect.width - 50), // Adjusted to keep the box fully inside the panel
        y: Math.min(Math.max(0, offsetY), rect.height - 50), // Adjusted to keep the box fully inside the panel
      });
      // Add the position to the positionsArray
      setPositionsArray([...positionsArray, { x: offsetX, y: offsetY }]);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    const sendData = async () => {
      try {
        const move = positionsArray.length.toString();
        const xpos = positionsArray[positionsArray.length - 1].x.toFixed(2);
        const ypos = positionsArray[positionsArray.length - 1].y.toFixed(2);
        
       // #for nodejs
        // const response = await axios.post("http://localhost:3001/send", {
        //   id:move,
        //   xpos:xpos,
        //   ypos:ypos
        // });


        // #for dotnet
          const response = await axios.post("https://localhost:7151/position", {
          id:move,
          xPos:xpos,
          yPos:ypos
        });
        console.log(response.data);
      } catch (error) {
        console.error("Error sending data:", error);
      }
    };
  
    if (positionsArray.length > 0) {
      sendData();
    }
  }, [positionsArray]);
  

  return (
    <div className="App">
      <button onClick={handleStartClick} disabled={isStarted}>
        Start
      </button>
      {isStarted && (
        <div
          className="panel"
          onMouseDown={handlePanelMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
        >
          <div className="box" style={{ left: position.x, top: position.y }}></div>
        </div>
      )}
      {positionsArray.length > 0 && (
        <table>
          <thead>
            <tr>
              <th>Move</th>
              <th>X Position</th>
              <th>Y Position</th>
            </tr>
          </thead>
          <tbody>
            {positionsArray.map((pos, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{(pos.x).toFixed(2)}</td>
                <td>{(pos.y).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default App;
